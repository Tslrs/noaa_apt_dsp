NOAA APT Decoder - macOS, Apple Silicon only (M1 / M2 / M3 / M4)

1. Install the free MATLAB Runtime R2026b (Apple Silicon version):
   https://www.mathworks.com/products/compiler/mcr/index.html
   (large download, needs an administrator password; no MATLAB licence needed)
2. Unzip this folder.
3. Open Terminal in this folder and run:
   xattr -dr com.apple.quarantine NOAA_APT_Decoder.app
   chmod +x run_NOAA_APT_Decoder.sh
   ./run_NOAA_APT_Decoder.sh /Applications/MATLAB/MATLAB_Runtime/R2026b
   (if the Runtime is installed somewhere else, use that folder instead)
   Double-clicking NOAA_APT_Decoder.app may also work; the app is not signed by Apple,
   so macOS may ask you to right-click -> Open the first time.
Not for Intel Macs, Windows or Linux.
